import React, { useState, useEffect } from 'react';
import { UserImage } from '../types';
import CopyIcon from './icons/CopyIcon';
import DownloadIcon from './icons/DownloadIcon';
import RetryIcon from './icons/RetryIcon';
import ShareIcon from './icons/ShareIcon';

interface ResultScreenProps {
  userImage: UserImage;
  generatedImage: string;
  generatedCaption: string;
  onTryAnother: () => void;
}

const dataUrlToFile = async (dataUrl: string, fileName: string): Promise<File | null> => {
  try {
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return new File([blob], fileName, { type: blob.type });
  } catch (error) {
    console.error("Error converting data URL to File:", error);
    return null;
  }
};

const ResultScreen: React.FC<ResultScreenProps> = ({ userImage, generatedImage, generatedCaption, onTryAnother }) => {
  const [showOriginal, setShowOriginal] = useState(false);
  const [captionCopied, setCaptionCopied] = useState(false);
  const [canShare, setCanShare] = useState(false);
  const [isSharing, setIsSharing] = useState(false);

  useEffect(() => {
    if (navigator.share) {
      setCanShare(true);
    }
  }, []);

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = generatedImage;
    link.download = 'alterevo-result.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const handleCopyCaption = () => {
    navigator.clipboard.writeText(generatedCaption);
    setCaptionCopied(true);
    setTimeout(() => setCaptionCopied(false), 2000);
  };

  const handleShare = async () => {
    if (!navigator.share) {
      alert("Sharing is not supported on your browser.");
      return;
    }

    setIsSharing(true);
    const imageFile = await dataUrlToFile(generatedImage, 'alterevo-share.png');
    
    if (!imageFile) {
        alert("Could not prepare image for sharing.");
        setIsSharing(false);
        return;
    }

    const shareData: ShareData = {
        title: 'My AlterEvo Creation!',
        text: generatedCaption,
        files: [imageFile],
    };
    
    try {
      if (navigator.canShare && navigator.canShare(shareData)) {
          await navigator.share(shareData);
      } else {
          // Fallback for browsers that can't share files but support text sharing
          await navigator.share({
              title: shareData.title,
              text: shareData.text,
          });
      }
    } catch (error) {
      // User cancellation is the most common reason for error, so we don't need to show an alert.
      console.log("Share action failed or was cancelled", error);
    } finally {
      setIsSharing(false);
    }
  };


  const imageToDisplay = showOriginal ? `data:${userImage.mimeType};base64,${userImage.base64}` : generatedImage;

  return (
    <div className="w-full max-w-4xl mx-auto px-4 flex flex-col items-center">
      <div className="relative w-full max-w-lg aspect-square mb-6">
        <img 
          src={imageToDisplay} 
          alt="Transformation result" 
          className="rounded-2xl w-full h-full object-cover border-2 border-gray-700 shadow-2xl shadow-purple-900/20"
        />
        <div className="absolute top-4 right-4 bg-gray-900/50 backdrop-blur-sm p-1 rounded-lg flex gap-1">
          <button onClick={() => setShowOriginal(false)} className={`px-3 py-1 text-sm rounded-md ${!showOriginal ? 'bg-purple-600 text-white' : 'text-gray-300'}`}>Transformed</button>
          <button onClick={() => setShowOriginal(true)} className={`px-3 py-1 text-sm rounded-md ${showOriginal ? 'bg-purple-600 text-white' : 'text-gray-300'}`}>Original</button>
        </div>
      </div>

      <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700 w-full max-w-lg text-center mb-6">
        <h3 className="text-lg font-semibold mb-2 text-purple-400">TikTok / Reels Hook</h3>
        <p className="text-gray-300 italic mb-4">"{generatedCaption}"</p>
        <button
          onClick={handleCopyCaption}
          className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-300 inline-flex items-center gap-2 text-sm"
        >
          <CopyIcon className="w-4 h-4" />
          {captionCopied ? 'Copied!' : 'Copy Caption'}
        </button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 w-full max-w-lg">
        {canShare && (
          <button
            onClick={handleShare}
            disabled={isSharing}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-transform transform hover:scale-105 duration-300 inline-flex items-center justify-center gap-2 disabled:bg-blue-800 disabled:cursor-wait"
          >
            <ShareIcon className="w-5 h-5" />
            {isSharing ? 'Preparing...' : 'Share'}
          </button>
        )}
        <button
          onClick={handleDownload}
          className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg transition-transform transform hover:scale-105 duration-300 inline-flex items-center justify-center gap-2"
        >
          <DownloadIcon />
          Download
        </button>
        <button
          onClick={onTryAnother}
          className="flex-1 bg-gray-600 hover:bg-gray-500 text-white font-bold py-3 px-6 rounded-lg transition-transform transform hover:scale-105 duration-300 inline-flex items-center justify-center gap-2"
        >
          <RetryIcon />
          Try Another Style
        </button>
      </div>
    </div>
  );
};

export default ResultScreen;