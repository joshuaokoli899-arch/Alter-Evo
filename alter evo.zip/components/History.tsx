import React from 'react';
import { HistoryItem } from '../types';

interface HistoryProps {
  history: HistoryItem[];
  onViewItem: (item: HistoryItem) => void;
  onClearHistory: () => void;
}

const History: React.FC<HistoryProps> = ({ history, onViewItem, onClearHistory }) => {
  if (history.length === 0) {
    return null;
  }

  return (
    <div className="w-full max-w-5xl mx-auto px-4 mt-12">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">Your Creations</h2>
        <button 
          onClick={onClearHistory}
          className="text-sm text-gray-400 hover:text-red-400 transition-colors"
          aria-label="Clear all items from history"
        >
          Clear History
        </button>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {history.map((item) => (
          <div
            key={item.id}
            onClick={() => onViewItem(item)}
            className="group relative aspect-square rounded-lg overflow-hidden cursor-pointer border-2 border-transparent hover:border-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 focus:ring-offset-gray-900 transition-all duration-300"
            tabIndex={0}
            role="button"
            aria-label={`View creation with style: ${item.style.name}`}
            onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && onViewItem(item)}
          >
            <img
              src={item.generatedImage}
              alt={`Generated image with ${item.style.name} style`}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-2">
              <p className="text-white text-xs font-semibold">{item.style.name}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default History;
