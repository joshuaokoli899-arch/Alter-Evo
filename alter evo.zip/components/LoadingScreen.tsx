
import React from 'react';
import { Style } from '../types';

interface LoadingScreenProps {
  style: Style;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ style }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center h-full">
      <div className="w-16 h-16 border-4 border-t-purple-500 border-gray-600 rounded-full animate-spin mb-6"></div>
      <h2 className="text-3xl font-bold mb-2">Evolving Your Alter Ego...</h2>
      <p className="text-lg text-gray-400">
        Applying the <span className="font-semibold text-purple-400">{style.name}</span> style.
      </p>
      <p className="text-sm text-gray-500 mt-4">This can take a moment, the AI is working its magic!</p>
    </div>
  );
};

export default LoadingScreen;
