import React, { useRef } from 'react';
import { STYLES } from '../constants';
import { HistoryItem, Style, UserImage } from '../types';
import UploadIcon from './icons/UploadIcon';
import History from './History';

interface StyleSelectorProps {
  onTransform: (image: UserImage, style: Style) => void;
  userImage: UserImage | null;
  setUserImage: (image: UserImage | null) => void;
  history: HistoryItem[];
  onViewHistoryItem: (item: HistoryItem) => void;
  onClearHistory: () => void;
}

const StyleSelector: React.FC<StyleSelectorProps> = ({ 
  onTransform, 
  userImage, 
  setUserImage,
  history,
  onViewHistoryItem,
  onClearHistory,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 4 * 1024 * 1024) { // 4MB limit
        alert("Please upload an image smaller than 4MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setUserImage({ base64: base64String, mimeType: file.type });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4">
      <div className="text-center mb-8 bg-gray-800/50 p-6 rounded-2xl border border-gray-700">
        <h2 className="text-2xl font-bold mb-2">1. Upload Your Selfie</h2>
        <p className="text-gray-400 mb-4">A clear, well-lit photo of your face works best!</p>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept="image/png, image/jpeg"
        />
        <button
          onClick={handleUploadClick}
          className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg transition-transform transform hover:scale-105 duration-300 inline-flex items-center gap-2"
        >
          <UploadIcon />
          {userImage ? 'Change Photo' : 'Choose a Photo'}
        </button>
        {userImage && (
          <div className="mt-6 flex justify-center">
            <img 
              src={`data:${userImage.mimeType};base64,${userImage.base64}`} 
              alt="Uploaded selfie" 
              className="rounded-lg w-40 h-40 object-cover border-2 border-purple-500 shadow-lg"
            />
          </div>
        )}
      </div>

      {userImage && (
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">2. Choose Your Style</h2>
          <p className="text-gray-400">Select a style to transform your photo.</p>
        </div>
      )}
      
      <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 transition-opacity duration-500 ${!userImage ? 'opacity-30 pointer-events-none' : 'opacity-100'}`}>
        {STYLES.map((style) => (
          <div
            key={style.id}
            onClick={() => userImage && onTransform(userImage, style)}
            className="group bg-gray-800 rounded-xl overflow-hidden border border-gray-700 hover:border-purple-500 cursor-pointer transition-all duration-300 transform hover:-translate-y-1"
          >
            <div className="relative">
              <img src={style.imageUrl} alt={style.name} className="w-full h-48 object-cover group-hover:opacity-80 transition-opacity" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <h3 className="absolute bottom-4 left-4 text-xl font-bold">{style.name}</h3>
            </div>
            <div className="p-4">
              <p className="text-gray-400 text-sm">{style.description}</p>
            </div>
          </div>
        ))}
      </div>
      <History 
        history={history} 
        onViewItem={onViewHistoryItem} 
        onClearHistory={onClearHistory}
      />
    </div>
  );
};

export default StyleSelector;
