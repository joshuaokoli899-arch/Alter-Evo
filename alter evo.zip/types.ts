export interface Style {
  id: string;
  name: string;
  description: string;
  imagePrompt: string;
  captionPrompt: string;
  imageUrl: string;
}

export type Screen = 'selector' | 'loading' | 'result';

export interface UserImage {
  base64: string;
  mimeType: string;
}

export interface HistoryItem {
  id: string;
  userImage: UserImage;
  generatedImage: string;
  generatedCaption: string;
  style: Style;
  timestamp: number;
}
