
import { GoogleGenAI, Modality } from '@google/genai';
import { UserImage } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * A custom error class to provide user-friendly feedback.
 */
class AIError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AIError';
  }
}

export async function generateImage(image: UserImage, prompt: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: image.base64,
              mimeType: image.mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
      config: {
          responseModalities: [Modality.IMAGE],
      },
    });

    // Check for safety blocks from the API response
    if (response.candidates?.[0]?.finishReason === 'SAFETY') {
      throw new AIError("The transformation was blocked for safety reasons. Please try a different photo.");
    }

    for (const part of response.candidates?.[0]?.content?.parts ?? []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    
    // This case means the API call succeeded but returned no image.
    throw new AIError("The AI couldn't create an image for this style. Please try a different one or adjust your photo.");

  } catch (error) {
    console.error("Error generating image:", error);
    if (error instanceof AIError) {
      // Re-throw our custom error to be caught by the UI
      throw error;
    }
    // For other errors (network, API key issues, etc.)
    throw new Error("Failed to connect to the AI service. Please check your connection and try again.");
  }
}

export async function generateCaption(prompt: string): Promise<string> {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        const text = response.text.trim();
        // Remove quotes if the model returns the caption in quotes
        return text.replace(/^"|"$/g, '');
    } catch (error) {
        console.error("Error generating caption:", error);
        return "Check out my AI transformation! #AlterEvo";
    }
}